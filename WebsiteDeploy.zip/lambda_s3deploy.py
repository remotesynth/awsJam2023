import boto3
import os
import mimetypes
# lambda-function
# triggered by changes in LD website codecommit repository
# reads files in the repository and uploads them to s3-bucket

# basically returns a list of a all files in the branch
def get_blob_list(codecommit, repository, branch):
    commitresponse = codecommit.get_differences(
        repositoryName=repository,
        afterCommitSpecifier=branch,
    )
    blob_list = [difference['afterBlob'] for difference in commitresponse['differences']]
    while 'nextToken' in commitresponse:
       commitresponse = codecommit.get_differences(
            repositoryName=repository,
            afterCommitSpecifier=branch,
            nextToken=commitresponse['nextToken']
        )
    blob_list += [difference['afterBlob'] for difference in commitresponse['differences']]
    return blob_list

def lambda_handler(event, context):
# target bucket
    bucket = boto3.resource('s3').Bucket(os.environ['s3BucketName'])
# source codecommit
    codecommit = boto3.client('codecommit', region_name=os.environ['codecommitRegion'])
    repository_name = os.environ['repository']
# reads each file in the branch and uploads it to the s3 bucket
    for blob in get_blob_list(codecommit, repository_name, os.environ['branch']):
        path = blob['path']
        content = (codecommit.get_blob(repositoryName=repository_name, blobId=blob['blobId']))['content']
# we have to guess the mime content-type of the files and provide it to S3 since S3 cannot do this on its own.
        content_type = mimetypes.guess_type(path)[0]
        if content_type is not None:
            bucket.put_object(Body=(content), Key=path, ContentType=content_type)
        else:
            bucket.put_object(Body=(content), Key=path)